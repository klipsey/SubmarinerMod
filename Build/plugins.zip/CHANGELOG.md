# 1.1.0

- Playable for Sots v3

# 1.0.9

- No more console spam

# 1.0.8

- Sots
- Chain is currently broken until gearbox fixes

# 1.0.7

- Buns Update

# 1.0.6

- Properly imported models 

# 1.0.5 

- Fixed backflip and actually synced swing

# 1.0.4

- Fixed mine and swing

# 1.0.3

- Maybe fixed client lag later in game?

# 1.0.2

- Fixed leftover self damage issues

# 1.0.1

- Read me update

# 1.0.0

- Release