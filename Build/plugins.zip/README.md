# Submariner

[![Submariner-Poster.png](https://i.postimg.cc/QxC1VtGS/Submariner-Poster.png)](https://postimg.cc/RNrNDv0n)

# Overview
### Submariner is close range combatant that regenerates health quickly as she fights more enemies. Positioning properly is important to managing her regeneration and movespeed bonuses.

[![Submariner-Char-Sheet.png](https://i.postimg.cc/kg9VKXLk/Submariner-Char-Sheet.png)](https://postimg.cc/kB1Xd9Jc)
| Keywords | Description|
| :------- |:---- |
| N'kuhanna's Restoration | Gain 10% increased health regen per stack. |

### This is a commissioned character. Redirect gameplay feedback to GoodGuy and bugfixes to me.
 
# Credits

tsuyoikenko - Code, model, animations.

goodguy - Commission, art and skill icons. Also commission him! discord: youredoingoodlad

Buns - Funded commission with his bread.